from setuptools import setup

setup(
    name='Mensajes',
    version='1.0',
    description='Un paquete para saludar y despedir',
    author='Eder Manjarres',
    author_email='hola@ktaca.dev',
    url='https://www.ktaca.dev',
    package=['mensajes','mensajes.hola','mensajes.adios'],
    scripts=['test.py']
)

